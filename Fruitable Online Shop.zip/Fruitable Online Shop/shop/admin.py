from django.utils.safestring import mark_safe
from django.contrib import admin
from .models import Category, Product, Client, JobCategory


# Category Product
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'body', 'price', 'discount_price', 'get_image', 'quantity', 'delivery')
    list_display_links = ('id', 'name')


    def get_image(self, product):
        if product.image:
            return mark_safe(f'<img src="{product.image.url}", width="75px">')
        return '4-0-4 Image not found!'

    get_image.short_description = "Object_Image"
    prepopulated_fields = { 'slug': ('name',)}



# Category Register
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')
    list_display_links = ('id', 'name')

    prepopulated_fields = { 'slug': ('name',)}  





# Client admn
@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = ('id', 'username', 'body','get_image',)
    list_display_links = ('id', 'username')


    def get_image(self, client):
        if client.image:
            return mark_safe(f'<img src="{client.image.url}", width="75px">')
        return '4-0-4 Image not found!'

    get_image.short_description = "Client_Image"
    prepopulated_fields = { 'slug': ('username',)}



# Job Cat
@admin.register(JobCategory)
class JobCategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'job')
    list_display_links = ('id', 'job')

    prepopulated_fields = { 'slug': ('job',)}  