from typing import Any
from django.views.generic import ListView, DetailView, UpdateView, CreateView, DeleteView
from django.shortcuts import render, redirect
from django.http import JsonResponse
from .models import Product, Category
from .models import Category, Product, Rating
from django.http import HttpResponse, HttpRequest


class ProductList(ListView):
    model = Product
    template_name = 'shop/index.html'
    context_object_name = 'products'
    extra_context = {
        'categories': Category.objects.all(),
        'title':'Fruitables - Online Shop',
        'page_name': "Shop"
    }


class AllProductsList(ProductList):
    template_name =  'shop/all_products.html'




class SortingProductList(AllProductsList):
    def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
        context = super().get_context_data(**kwargs) 
        products = Product.objects.filter(filter_choice=self.kwargs['key_name'])
        context['products'] = products
        return context



class SortingBySubcategories(AllProductsList):
    def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
        context = super().get_context_data(**kwargs)
        subcategory = Category.objects.get(slug=self.kwargs['slug'])
        context['products'] = subcategory.product_set.all()
        return context



# new opportunities
class ProductDetail(DetailView):
    model = Product
    context_object_name ='product'
    extra_context = {
        'page_name': "Shop Detail",
        'categories': Category.objects.filter(parent=None)
    }


    # def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
    #     context =  super().get_context_data(**kwargs)
    #     product = Product.objects.get(slug=self.kwargs['slug'])
    #     rating = Rating.objects.filter(product=product, user=self.request.user).first()
    #     context['user_rating'] = rating.rating if rating else 0
    #     return context



def index(request: HttpRequest) -> HttpResponse:
    posts = Product.objects.all()
    for post in posts:
        rating = Rating.objects.filter(post=post, user=request.user).first()
        post.user_rating = rating.rating if rating else 0
    return render(request, 'index.html', {'posts':posts})



def rate(request: HttpRequest, product_id:int, rating:int) -> HttpResponse:
    product = Product.objects.get(pk=product_id)
    Rating.objects.filter(product = product, user=request.user).delete()
    product.rating_set.create(user=request.user, rating=rating)
    return redirect('detail', slug=product.slug)




# Bosh sahifaga malumotlarni kod ko'rinishida chiqarish uchun ishlatilgan amal!
def main_view(request):
    categories = Category.objects.all()
    products = Product.objects.all()
    categories_data = [{'id': category.id, 'name': category.name} for category in categories]
    products_data = [{'id': product.id, 'name': product.name, 'category_id': product.category_id} for product in products]
    response_data = {'categories': categories_data, 'products': products_data}
#     return JsonResponse(response_data)

def contact(request):
    return render(request, 'shop/contact.html')



def testimonial(request):
    return render(request, 'shop/testimonial.html')