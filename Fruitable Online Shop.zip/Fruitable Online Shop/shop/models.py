from django.contrib.auth.models import User
from django.db import models


class Category(models.Model):
    name = models.CharField(max_length=60, verbose_name="Kategoriya", unique=True)
    image = models.ImageField(upload_to='categories/', blank=True, null=True)
    slug = models.SlugField(null=True, blank=True, unique=True)
    parent = models.ForeignKey('self', on_delete=models.CASCADE, blank=True, null=True, related_name='subcategories')

    def __str__(self) -> str:
        return self.name

FILES_CHOICES = {
    'fru':'Fruits',
    'fan':'Fantastic',
    'bom':'Boombastic',
    'tul':'Tools',
    'fur':'Furniture',
}


class Product(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    filter_choice = models.CharField(max_length=3, choices=FILES_CHOICES, null=True)
    name = models.CharField(max_length=255)
    body = models.TextField()
    price = models.DecimalField(decimal_places=2, max_digits=10)
    discount_price = models.DecimalField(decimal_places=2, max_digits=10,blank=True, null=True)
    image = models.ImageField(upload_to='[products/', verbose_name="Object_Image")
    quantity = models.IntegerField(default=0) 
    quantity_kg = models.IntegerField(default=0) 
    delivery = models.BooleanField(default=False)
    slug = models.SlugField(null=True, blank=True, unique=True)


    @property
    def stock_status(self):
        return bool(self.quantity)


    def __str__(self):
        return f'{self.name}'
    


class Rating(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    rating = models.IntegerField(default=0) 

    def __str__(self) -> str:
        return f"{self.product.name}: {self.rating}"
    


class JobCategory(models.Model):
    job = models.CharField(max_length=50, unique=True, verbose_name="Ish_turi")
    slug = models.SlugField(null=True, blank=True, unique=True)

    def __str__(self) -> str:
        return self.job



class Client(models.Model):
    category = models.ForeignKey(JobCategory, on_delete=models.CASCADE)
    username = models.CharField(max_length=50, unique=True, verbose_name="Client_ismi")
    image = models.ImageField(upload_to='avatar/', blank=True, null=True)
    body = models.TextField()
    slug = models.SlugField(null=True, blank=True, unique=True)
