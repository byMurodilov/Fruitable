from django.urls import path
from . import views

urlpatterns = [
    path('', views.ProductList.as_view(), name='index'),
    path('products/', views.AllProductsList.as_view(), name='all_products'),
    path('contact/', views.contact, name='contact' ),
    path('testimonial/', views.testimonial, name='testimonial' ),
    path('sorting/<slug:key_name>/', views.SortingProductList.as_view(), name='sorting'),
    path('subcategory/<slug:slug>/', views.SortingBySubcategories.as_view(), name='subcategory'),
    path('detail/<int:pk>/', views.ProductDetail.as_view(), name='detail'),
    path('rate/<int:product_id>/<int:rating>/', views.rate),
]